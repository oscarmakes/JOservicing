JOservicing Customer Portal
=============================

UPLOAD:
1. Unzip this folder.
2. Upload index.html, style.css and script.js to the same GitHub Pages repository.
3. Open your GitHub Pages website.

WHAT IT DOES:
- Shows a login screen immediately.
- Lets customers create an account and log in.
- Lets a logged-in customer create a Basic (£30) or Full (£50) service booking.
- Shows only orders belonging to the currently logged-in email.
- New bookings appear under Current Orders with "In Process".
- Completed/Cancelled orders appear under Past Orders.

IMPORTANT:
This version is designed for GitHub Pages and stores accounts/orders in the visitor's browser using localStorage. It is NOT a secure production authentication/database system. A real customer portal needs a server-side database and proper authentication so customers can securely access their orders across different devices.

For a real business version, the next upgrade should use a backend such as Supabase/Firebase or a custom server with secure password hashing and database rules.
